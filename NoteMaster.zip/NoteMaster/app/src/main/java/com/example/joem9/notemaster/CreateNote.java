package com.example.joem9.notemaster;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.FileProvider;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CreateNote extends FragmentActivity implements LocationListener{
    DBManager db;

    EditText addName;
    EditText addDescription ;
    Button pictureButton;
    Button addButton;
    ImageView mImageView;
    String photoFilePath = "";

    double latitude;
    double longitude;

    String GPS = "";

    private LocationManager locationManager;
    private TextView tv_latitude;
    private TextView tv_longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note);

        mImageView = (ImageView) findViewById(R.id.imageCaptured);
        addName = (EditText) findViewById(R.id.addNoteName);
        addDescription = (EditText) findViewById(R.id.addNoteDesc);
        pictureButton = (Button) findViewById(R.id.addPicButton);
        addButton = (Button) findViewById(R.id.addButton);

        db = new DBManager(this);

        /**
         * NOT MY OWN CODE
         * Created by pethoalpar on 4/13/2016.
         * https://github.com/pethoalpar/AndroidGpsSpeedExample/blob/master/app/src/main/java/com/pethoalpar/androidgpsspeedexample/MainActivity.java
         * https://github.com/pethoalpar/GpsExample/blob/master/app/src/main/java/com/example/pethoalpar/gpsexample/GpsTool.java
         */
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},120);
        }else{
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,0,this);
            this.onLocationChanged(null);
        }
        /***
         * END NOT MINE
         * **/

        AddData();
    }

    /**
     * Created by pethoalpar on 4/13/2016.
     * https://github.com/pethoalpar/AndroidGpsSpeedExample/blob/master/app/src/main/java/com/pethoalpar/androidgpsspeedexample/MainActivity.java
     * https://github.com/pethoalpar/GpsExample/blob/master/app/src/main/java/com/example/pethoalpar/gpsexample/GpsTool.java
     */
    @Override
    public void onLocationChanged(Location location) {
        if(location == null){
        }else{
            latitude = location.getLatitude();

            longitude = location.getLongitude();
        }

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
    /***
     * END NOT MINE
     * **/


    public void AddData() {

        Calendar c = Calendar.getInstance();
        SimpleDateFormat simpleDate = new SimpleDateFormat("dd/MMM/yyyy");
        final String date = simpleDate.format(c.getTime());

        pictureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent intent = new Intent(CreateNote.this, Camera.class);
            startActivityForResult(intent,1);
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

            GPS = latitude + " / " + longitude;

            boolean isInserted = db.newNote(
                    addName.getText().toString(),
                    addDescription.getText().toString(),
                    photoFilePath,
                    date,
                    GPS
            );

            if(isInserted == true) {
                Toast.makeText(CreateNote.this, getString(R.string.data_inserted), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(CreateNote.this, getString(R.string.data_not_inserted), Toast.LENGTH_LONG).show();
            }
            db.close();
            finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        // Gets path of photo taken, stores it for DB storage

        String pathResult = data.getExtras().get("photoPath").toString();
        File fPath = new File(pathResult);
        Uri photoURI = FileProvider.getUriForFile(this, "com.example.android.fileprovider", fPath);

        mImageView.setImageURI(photoURI);
        photoFilePath = pathResult;

    }


}
