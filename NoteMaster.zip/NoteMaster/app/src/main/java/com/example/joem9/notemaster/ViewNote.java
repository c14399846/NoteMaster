package com.example.joem9.notemaster;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ViewNote extends AppCompatActivity {

    DBManager db = new DBManager(this);
    Adapter adapter;
    ListView listview;
    ArrayList<Item> arrayList = new ArrayList<Item>();

    //Displays the ListView with use of custom adapter
    public void displayNotes() {

        setContentView(R.layout.activity_view_note);
        final Cursor cursor = db.getAllData();

        if(cursor != null){
            if(cursor.moveToFirst()){
                do {
                    Item note = new Item();
                    note.setID(cursor.getString(0));
                    note.setName(cursor.getString(1));
                    note.setDescription(cursor.getString(2));
                    note.setImage(cursor.getString(3));
                    note.setDate(cursor.getString(4));
                    arrayList.add(note);
                } while(cursor.moveToNext());
            }
        }

        adapter = new Adapter(this, R.layout.list_note_view, arrayList);
        listview = (ListView) findViewById(R.id.list_note);
        listview.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                final Item note = arrayList.get(position);
                final int noteID = Integer.parseInt(note.getID());

                Intent intent = new Intent(ViewNote.this, EditNote.class);
                intent.putExtra("ID",noteID);
                startActivityForResult(intent,1);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                //Restarts the ListView Intent with updated List data
                Intent intent = getIntent();
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                finish();
                startActivity(intent);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        displayNotes();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            db.close();
        }
        return super.onKeyDown(keyCode, event);
    }

}