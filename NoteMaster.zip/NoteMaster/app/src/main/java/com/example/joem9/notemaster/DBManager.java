package com.example.joem9.notemaster;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBManager
{
    public static final String KEY_ROWID 	= "_id";
    public static final String KEY_NOTENAME 	= "noteName";
    public static final String KEY_DESCRIPTION 	= "description";
    public static final String KEY_DATETAKEN 	= "dateTaken";
    public static final String KEY_LOCATION 	= "location";
//    public static final String KEY_DATEDUE 	= "dateDue";
//    public static final String KEY_STATUS 	= "status";
    public static final String KEY_PHOTOPATH = "photopath";

    private static final String DATABASE_NAME 	= "NotesList";
    private static final String DATABASE_TABLE 	= "Notes";
    private static final int DATABASE_VERSION 	= 1;

    private static final String DATABASE_CREATE =
                    "create table Notes " +
                    "(" +
                    "_id integer primary key autoincrement," +
                    "noteName text not null," +
                    "description text not null," +
                    "photopath text not null," +
                    "dateTaken text not null," +
                    "location text not null" +
                    ");";

    private final Context  context;
    private DatabaseHelper DBHelper;
    private SQLiteDatabase db;


    public DBManager(Context ctx)
    {
        this.context 	= ctx;
        DBHelper 		= new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS" + DATABASE_TABLE);
            onCreate(db);
        }
    }

    public boolean newNote(String insNote, String insDesc, String photoPath, String date, String location) {
        SQLiteDatabase db =  DBHelper.getWritableDatabase();
        ContentValues initValues = new ContentValues();
        initValues.put(KEY_NOTENAME, insNote);
        initValues.put(KEY_DESCRIPTION, insDesc);
        initValues.put(KEY_PHOTOPATH, photoPath);
        initValues.put(KEY_DATETAKEN, date);
        initValues.put(KEY_LOCATION, location);

        long inserted = db.insert(DATABASE_TABLE, null, initValues);

        if(inserted == -1) {
            return false;
        } else {
            return true;
        }
    }

    public void deleteNote(int id){
        SQLiteDatabase db =  DBHelper.getWritableDatabase();
        String delSQL = "delete from " + DATABASE_TABLE + " where " + KEY_ROWID + "='" + id +"'";
        db.execSQL(delSQL);
    }

    public boolean deletePhoto(int id) {
        SQLiteDatabase db =  DBHelper.getWritableDatabase();
        ContentValues initValues = new ContentValues();
        initValues.put(KEY_PHOTOPATH, "");
        long inserted = db.update(DATABASE_TABLE, initValues, KEY_ROWID + " = ?", new String[]{Integer.toString(id)});

        if(inserted == -1) {
            return false;
        } else {
            return true;
        }
    }

    public String getGPS(int id) {
        String location = null;
        SQLiteDatabase db = DBHelper.getWritableDatabase();
        String dateSQL = "select * from " + DATABASE_TABLE + " WHERE " + KEY_ROWID + " ='" + id + "'";
        Cursor res = db.rawQuery(dateSQL, null);

        if(res.moveToFirst()){
            location = res.getString(res.getColumnIndex(KEY_LOCATION));
        }

        return location;
    }

    public String getPhotoPath(int id) {
        String path = null;
        SQLiteDatabase db = DBHelper.getWritableDatabase();
        String pathSQL = "select * from " + DATABASE_TABLE + " WHERE " + KEY_ROWID + " ='" + id + "'";
        Cursor res = db.rawQuery(pathSQL, null);

        if(res.moveToFirst()){
            path = res.getString(res.getColumnIndex(KEY_PHOTOPATH));
        }

        return path;
    }

    public String getDateTaken(int id) {
        String date = null;
        SQLiteDatabase db = DBHelper.getWritableDatabase();
        String dateSQL = "select * from " + DATABASE_TABLE + " WHERE " + KEY_ROWID + " ='" + id + "'";
        Cursor res = db.rawQuery(dateSQL, null);

        if(res.moveToFirst()){
            date = res.getString(res.getColumnIndex(KEY_DATETAKEN));
        }

        return date;
    }

    public boolean updatePhoto(int id, String path) {
        SQLiteDatabase db =  DBHelper.getWritableDatabase();
        ContentValues initValues = new ContentValues();
        initValues.put(KEY_PHOTOPATH, path);

        long inserted = db.update(DATABASE_TABLE, initValues, KEY_ROWID + " = ?", new String[]{Integer.toString(id)});

        if(inserted == -1) {
            return false;
        } else {
            return true;
        }
    }
    
    public boolean updateWholeNote(int id, String insNote, String insDesc) {
        SQLiteDatabase db =  DBHelper.getWritableDatabase();
        ContentValues initValues = new ContentValues();
        initValues.put(KEY_NOTENAME, insNote);
        initValues.put(KEY_DESCRIPTION, insDesc);

        long inserted = db.update(DATABASE_TABLE, initValues, KEY_ROWID + " = ?", new String[]{Integer.toString(id)});

        if(inserted == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean updateName(int id, String insName) {
        SQLiteDatabase db =  DBHelper.getWritableDatabase();
        ContentValues initValues = new ContentValues();
        initValues.put(KEY_NOTENAME, insName);

        long inserted = db.update(DATABASE_TABLE, initValues, KEY_ROWID + " = ?", new String[]{Integer.toString(id)});

        if(inserted == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean updateDesc(int id, String insDesc) {
        SQLiteDatabase db =  DBHelper.getWritableDatabase();
        ContentValues initValues = new ContentValues();
        initValues.put(KEY_DESCRIPTION, insDesc);

        long inserted = db.update(DATABASE_TABLE, initValues, KEY_ROWID + " = ?", new String[]{Integer.toString(id)});

        if(inserted == -1) {
            return false;
        } else {
            return true;
        }
    }

    public void close() {
        DBHelper.close();
    }

    public Cursor getAllData() {
        SQLiteDatabase db = DBHelper.getWritableDatabase();
        String allSQL = "select * from " + DATABASE_TABLE;
        Cursor res = db.rawQuery(allSQL, null);
        return res;
    }

}