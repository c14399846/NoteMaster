package com.example.joem9.notemaster;

// Edit multiple fields in the note (Name, Description, Image)
// Can View Note too

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.Locale;

public class EditNote extends AppCompatActivity {

    ImageView mImageView;
    TextView textDate;
    EditText editName;
    EditText editDescription;

    Button submitButton;
    Button subDeleteButton;
    Button subEditPhotoButton;
    Button subDeletePhotoButton;
    Button subCancelButton;
    Button gpsButton;

    boolean deletePhoto = false;
    boolean editPhoto ;

    String date = "";
    String photoFilePath = "";
    String oldPhotoFilePath = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);

        // ID of Note in Databse
        final int noteID = Integer.parseInt(getIntent().getExtras().get("ID").toString());

        final DBManager db = new DBManager(this);

        // Used to refresh List
        final Intent returnIntent = new Intent();

        // Check if delete or edit buttons were used
        deletePhoto = false;
        editPhoto = false;

        mImageView = (ImageView) findViewById(R.id.imageEditCaptured);
        textDate = (TextView) findViewById(R.id.edit_tv_Date);
        editName = (EditText) findViewById(R.id.editNoteName);
        editDescription = (EditText) findViewById(R.id.editNoteDesc);

        submitButton = (Button) findViewById(R.id.subEditButton);
        subDeleteButton = (Button) findViewById(R.id.subDeleteButton);
        subEditPhotoButton = (Button) findViewById(R.id.subEditPhotoButton);
        subDeletePhotoButton = (Button) findViewById(R.id.subDeletePhotoButton);
        subCancelButton = (Button) findViewById(R.id.subCancelButton);
        gpsButton = (Button) findViewById(R.id.gpsButton);

        // Date of Note creation
        date = db.getDateTaken(noteID);
        textDate.setText(date);

        // Image path
        photoFilePath = db.getPhotoPath(noteID);
        if(photoFilePath != null && !photoFilePath.isEmpty()){
            File pathF = new File(photoFilePath);
            Uri photoURI = FileProvider.getUriForFile(this, "com.example.android.fileprovider", pathF);
            mImageView.setImageURI(photoURI);
        }

        gpsButton.setOnClickListener(new View.OnClickListener() {
             public void onClick(View v) {
                String location = db.getGPS(noteID);

                 String[] locationFull = location.split("/");
                 String part1 = locationFull[0];
                 String part2 = locationFull[1];

                Double lat = Double.parseDouble(part1);
                Double longitude = Double.parseDouble(part2);

                 // Dublin Locations
//                lat = 53.3498;
//                longitude = -6.2603;

                String uri = String.format(Locale.ENGLISH, "geo:%f,%f", lat, longitude);
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                startActivity(intent);
             }
         });

        // Delete Note button
        subDeleteButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(EditNote.this);
                alert.setTitle(getString(R.string.delete));
                alert.setMessage(getString(R.string.sure_delete_note));

                alert.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                alert.setPositiveButton(getString(R.string.yes),new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    db.deleteNote(noteID);
                    setResult(RESULT_OK, returnIntent);
                    finish();
                    }
                });

                AlertDialog dialog = alert.create();

                dialog.show();
            }
        });

        // Edit Note button
        subEditPhotoButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                editPhoto = true;
                Intent intent = new Intent(EditNote.this, Camera.class);
                startActivityForResult(intent,1);
            }
        });

        // Delete Photo Button
        subDeletePhotoButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(EditNote.this);
                alert.setTitle(getString(R.string.delete));
                alert.setMessage(getString(R.string.sure_delete_photo));

                alert.setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                alert.setPositiveButton(getString(R.string.yes),new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    deletePhoto = true;
//                    db.deletePhoto(position);
                    mImageView.setImageResource(0);
                    }
                });

                AlertDialog dialog = alert.create();

                dialog.show();
            }
        });

        // Cancel any edits button
        subCancelButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                setResult(RESULT_CANCELED, returnIntent);
                finish();
            }
        });

        // Submission of any changes button
        submitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String name = editName.getText().toString();
                String desc = editDescription.getText().toString();

                // Checks for Name or Description changes
                // RESULT_OK used to refresh the List, it makes the Intent re-instantiate itself after a callback
                // only if something is changed, to prevent waste of resources

                boolean bName = (!name.equals(null) && !name.isEmpty());
                boolean bDesc = (!desc.equals(null) && !desc.isEmpty());

                // If both changed
                if(bName && bDesc ) {
                    db.updateWholeNote(noteID, name, desc);
                    setResult(RESULT_OK, returnIntent);
                }

                // If name changed
                else if(bName && !bDesc) {
                    db.updateName(noteID, name);
                    setResult(RESULT_OK, returnIntent);
                }

                // If Description changed
                else if(!bName && bDesc) {
                    db.updateDesc(noteID, desc);
                    setResult(RESULT_OK, returnIntent);
                }

                // Nothing changed
                else if (!deletePhoto) {
                    setResult(RESULT_CANCELED, returnIntent);
                }

                // Failure of some sort
                else {
                    setResult(RESULT_CANCELED, returnIntent);
                }

                // If Edited the photo
                if(editPhoto) {
                    //delete original photo
                    File delFile = new File(oldPhotoFilePath);
                    delFile.delete();
                    setResult(RESULT_OK, returnIntent);
                    db.updatePhoto(noteID, photoFilePath);
                }

                // If Deleted the photo
                if (deletePhoto){
                    File delFile = new File(photoFilePath);
                    delFile.delete();
                    setResult(RESULT_OK, returnIntent);
                    db.deletePhoto(noteID);
                }

                finish();
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                if(editPhoto){

                    // old file path stored
                    oldPhotoFilePath = photoFilePath;

                    // Get path from  newly taken photo from Camera Intent
                    String pathResult = data.getExtras().get("photoPath").toString();
                    File fPath = new File(pathResult);
                    Uri photoURI = FileProvider.getUriForFile(this, "com.example.android.fileprovider", fPath);

                    mImageView.setImageURI(photoURI);
                    editPhoto = true;
                    deletePhoto = false;
                    photoFilePath = pathResult;
                }
            }

        }
    }

}
