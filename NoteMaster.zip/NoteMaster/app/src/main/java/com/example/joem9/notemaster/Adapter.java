package com.example.joem9.notemaster;

import android.app.Activity;
import android.net.Uri;
import android.support.v4.content.FileProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class Adapter extends ArrayAdapter<Item> {

    ArrayList<Item> notes;
    private Activity activity;
    int id;

    public Adapter(Activity context, int resource, ArrayList<Item> objects){
        super(context, resource, objects);
        this.activity = context;
        this.id = resource;
        this.notes = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView == null){
            LayoutInflater inflater = activity.getLayoutInflater();
            convertView = inflater.inflate(id, null);
        }

        Item note = notes.get(position);

        ImageView tv_Img = (ImageView) convertView.findViewById(R.id.tv_Img);
        TextView tv_Name = (TextView) convertView.findViewById(R.id.tv_Name);
        TextView tv_Description = (TextView) convertView.findViewById(R.id.tv_Desc);
        TextView tv_Date = (TextView) convertView.findViewById(R.id.tv_Date);

        String imgURI = note.getImage();

        if( imgURI != null && !imgURI.isEmpty()){
            File file = new File(imgURI);
            Uri photoURI;
            photoURI = FileProvider.getUriForFile(activity, "com.example.android.fileprovider", file);
            tv_Img.setImageURI(photoURI);
        }

        tv_Name.setText(note.getName());
        tv_Description.setText(note.getDescription());
        tv_Date.setText(note.getDate());

        return convertView;
    }
}